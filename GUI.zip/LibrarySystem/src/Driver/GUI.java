package Driver;

import Entity.Author;
import Entity.Book;
import Entity.Date;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

public class GUI extends Application {

    public static ArrayList<Book> bookArrayList = new ArrayList<>();

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        TabPane tabPane = new TabPane();
        tabPane.setLayoutX(14.0);
        tabPane.setLayoutY(14.0);
        tabPane.setPrefWidth(442.0);
        tabPane.setPrefHeight(375.0);
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab bookTab = new Tab();
        bookTab.setText("Book");
        VBox bookContent = new VBox();
        bookContent.setSpacing(15);
        bookContent.setAlignment(Pos.CENTER);
        Button insertBookButton = new Button("Insert new Book");
        insertBookButton.setPrefWidth(230);
        Button searchBookTitleButton = new Button("Search Book By Title");
        searchBookTitleButton.setPrefWidth(230);
        Button searchBookNumberButton = new Button("Search Book By Number");
        searchBookNumberButton.setPrefWidth(230);
        Button searchBookAuthorButton = new Button("Search Book By Author Name");
        searchBookAuthorButton.setPrefWidth(230);
        Button checkLoansButton = new Button("Book Loans");
        checkLoansButton.setPrefWidth(230);
        Button saveButton = new Button("Browse for File to save");
        saveButton.setPrefWidth(230);
        insertBookButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        insertBookButton.setAlignment(Pos.CENTER);

        searchBookTitleButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        searchBookTitleButton.setAlignment(Pos.CENTER);


        searchBookNumberButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        searchBookNumberButton.setAlignment(Pos.CENTER);

        searchBookAuthorButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        searchBookAuthorButton.setAlignment(Pos.CENTER);

        checkLoansButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        checkLoansButton.setAlignment(Pos.CENTER);

        saveButton.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        saveButton.setAlignment(Pos.CENTER);

        bookContent.getChildren().addAll(insertBookButton, searchBookTitleButton,
                searchBookNumberButton, searchBookAuthorButton, checkLoansButton, saveButton);
        bookTab.setContent(bookContent);
        tabPane.getTabs().add(bookTab);

        insertBookButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                insertBookButtonInterface();
            }
        });


        searchBookTitleButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                searchBookButtonInterface("Title");
            }
        });

        searchBookNumberButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                searchBookButtonInterface("Number");
            }
        });

        searchBookAuthorButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                searchBookButtonInterface("Author Name");
            }
        });
        checkLoansButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                checkBookLoansButton();
            }
        });

        saveButton.setOnAction(new EventHandler() {

            @Override
            public void handle(Event event) {
                DirectoryChooser chooser = new DirectoryChooser();
                chooser.setTitle("JavaFX Projects");

                File defaultDirectory = new File("C:/");
                chooser.setInitialDirectory(defaultDirectory);

                File selectedDirectory = chooser.showDialog(primaryStage);


                if (selectedDirectory != null) {

                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Books Info\n");

                    for (Book book : bookArrayList) {
                        stringBuilder.append(book.getInfo()).append("\n");
                        stringBuilder.append("-----------------------------------").append("\n");
                    }
                    File fileToSave = new File((selectedDirectory) + "/output.txt");
                    System.out.println(selectedDirectory);
                    System.out.println(fileToSave.getPath());
                    try {
                        FileWriter writer = new FileWriter(fileToSave);
                        writer.write(stringBuilder.toString());
                        writer.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setHeaderText("File saved");
                    alert.setContentText("");
                    alert.showAndWait();
                } else {

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setHeaderText("Choose Directory to save file in");
                    alert.setContentText("");
                    alert.showAndWait();
                }
            }
        });
        Scene scene = new Scene(tabPane, 625.0, 460.0);
        primaryStage.setTitle("Library System");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void insertBookButtonInterface() {

        Stage stage = new Stage();
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(10);
        pane.setVgap(10);

        Label bookTitle = new Label("Book title");
        // set label style by chang border width ,border color ,background color,font weight
        bookTitle.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookTitle.setAlignment(Pos.CENTER);

        Label authorId = new Label("Author ID");
        // set label style by chang border width ,border color ,background color,font weight
        authorId.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        authorId.setAlignment(Pos.CENTER);

        Label authorName = new Label("Author Name");
        // set label style by chang border width ,border color ,background color,font weight
        authorName.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        authorName.setAlignment(Pos.CENTER);

        Label authorAddress = new Label("Author Address");
        // set label style by chang border width ,border color ,background color,font weight
        authorAddress.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        authorAddress.setAlignment(Pos.CENTER);

        Label authorBirthDate = new Label("Author Birth Date");
        // set label style by chang border width ,border color ,background color,font weight
        authorBirthDate.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        authorBirthDate.setAlignment(Pos.CENTER);

        Label bookNumber = new Label("Book Number");
        // set label style by chang border width ,border color ,background color,font weight
        bookNumber.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookNumber.setAlignment(Pos.CENTER);

        Label bookGenre = new Label("Book Genre");
        // set label style by chang border width ,border color ,background color,font weight
        bookGenre.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookGenre.setAlignment(Pos.CENTER);

        Label bookVersion = new Label("Book version");
        // set label style by chang border width ,border color ,background color,font weight
        bookVersion.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookVersion.setAlignment(Pos.CENTER);

        Label bookData = new Label("Book Date");
        // set label style by chang border width ,border color ,background color,font weight
        bookData.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookData.setAlignment(Pos.CENTER);


        TextField bookTitleText = new TextField();
        bookTitleText.setPromptText("Book Title");
        // set text style by chang border width ,border color ,background color,font weight
        bookTitleText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookTitleText.setAlignment(Pos.CENTER);


        TextField authorIdText = new TextField();
        authorIdText.setPromptText("Author ID");
        // set text style by chang border width ,border color ,background color,font weight
        authorIdText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        authorIdText.setAlignment(Pos.CENTER);


        TextField authorNameText = new TextField();
        authorNameText.setPromptText("Author Name");
        // set text style by chang border width ,border color ,background color,font weight
        authorNameText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        authorNameText.setAlignment(Pos.CENTER);

        TextField authorAddressText = new TextField();
        authorAddressText.setPromptText("Author Address");
        // set text style by chang border width ,border color ,background color,font weight
        authorAddressText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        authorAddressText.setAlignment(Pos.CENTER);

        DatePicker authorDateText = new DatePicker();
        authorDateText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");


        TextField bookNumberText = new TextField();
        bookNumberText.setPromptText("Book Number");
        // set text style by chang border width ,border color ,background color,font weight
        bookNumberText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookNumberText.setAlignment(Pos.CENTER);

        TextField bookGenreText = new TextField();
        bookGenreText.setPromptText("Book Genre");
        // set text style by chang border width ,border color ,background color,font weight
        bookGenreText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookGenreText.setAlignment(Pos.CENTER);

        TextField bookVersionText = new TextField();
        bookVersionText.setPromptText("Book Version");
        // set text style by chang border width ,border color ,background color,font weight
        bookVersionText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookVersionText.setAlignment(Pos.CENTER);

        DatePicker bookDateText = new DatePicker();
        bookDateText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");

        Button insert = new Button("Add New Book");
        // set style to button by change background color ,font size, border width ,font weight ,border color ,border radius , background radius and text fill
        insert.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        insert.setAlignment(Pos.CENTER);
        insert.setOnAction(new EventHandler() {
            @Override
            public void handle(Event actionEvent) {

                if (bookTitleText.getText().isEmpty() || bookNumberText.getText().isEmpty() ||
                        bookGenreText.getText().isEmpty() ||
                        bookVersionText.getText().isEmpty() || authorIdText.getText().isEmpty()
                        || authorNameText.getText().isEmpty() || authorAddressText.getText().isEmpty()
                        || authorDateText.getValue() == null || bookDateText.getValue() == null) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setContentText("you must insert  data correctly ");
                    alert.showAndWait();
                } else if (!isInteger(authorIdText) || !isInteger(bookNumberText)) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setContentText("Author ID And Book Number must be Integers");
                    alert.showAndWait();
                } else {
                    LocalDate authorLocalDate = authorDateText.getValue();
                    Date authorDate = new Date(authorLocalDate.getDayOfMonth(), authorLocalDate.getMonthValue(), authorLocalDate.getYear());

                    LocalDate bookLocalDate = bookDateText.getValue();
                    Date bookDate = new Date(bookLocalDate.getDayOfMonth(), bookLocalDate.getMonthValue(), bookLocalDate.getYear());
                    Author author = new Author(authorIdText.getText(), authorNameText.getText(), authorAddressText.getText(), authorDate);
                    Book book = new Book(bookTitleText.getText(), author, Integer.parseInt(bookNumberText.getText()),
                            bookGenreText.getText(), bookVersionText.getText(), bookDate, false);

                    bookArrayList.add(book);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setHeaderText("the Book has been added");
                    alert.setContentText("");
                    alert.showAndWait();

                    bookTitleText.clear();
                    bookNumberText.clear();
                    bookGenreText.clear();
                    bookVersionText.clear();
                    authorIdText.clear();
                    authorAddressText.clear();
                    authorNameText.clear();
                }


            }

        });


        pane.add(bookTitle, 0, 0);
        pane.add(bookTitleText, 1, 0);
        pane.add(authorId, 0, 1);
        pane.add(authorIdText, 1, 1);
        pane.add(authorName, 0, 2);
        pane.add(authorNameText, 1, 2);
        pane.add(authorAddress, 0, 3);
        pane.add(authorAddressText, 1, 3);


        pane.add(authorBirthDate, 0, 4);
        pane.add(authorDateText, 1, 4);
        pane.add(bookNumber, 0, 5);
        pane.add(bookNumberText, 1, 5);
        pane.add(bookGenre, 0, 6);
        pane.add(bookGenreText, 1, 6);
        pane.add(bookVersion, 0, 7);
        pane.add(bookVersionText, 1, 7);
        pane.add(bookData, 0, 8);
        pane.add(bookDateText, 1, 8);
        pane.add(insert, 2, 9);
        // put the  pane in the middle of the interface
        pane.widthProperty().divide(2);
        pane.heightProperty().divide(2);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.setWidth(600);
        stage.show();


    }


    public void searchBookButtonInterface(String searchFiled) {

        Stage stage = new Stage();
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(10);
        pane.setVgap(10);

        Label bookName = new Label(searchFiled);
        // set label style by chang border width ,border color ,background color,font weight
        bookName.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");
        bookName.setAlignment(Pos.CENTER);


        TextField bookNameText = new TextField();
        bookNameText.setPromptText(searchFiled);
        // set text style by chang border width ,border color ,background color,font weight
        bookNameText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookNameText.setAlignment(Pos.CENTER);


        Button search = new Button("Search for a  Book");
        // set text style by chang border width ,border color ,background color,font weight
        search.setStyle("-fx-background-color:orange; -fx-font-size:14; -fx-border-width: 0px0px2px0px; -fx-font-weight: bold; -fx-border-color: #000000;  -fx-border-radius : 30 ; -fx-background-radius : 30 ;-fx-text-fill:  #654b00; ");
        search.setAlignment(Pos.CENTER);
        search.setOnAction(new EventHandler() {
            @Override
            public void handle(Event event) {

                if (bookNameText.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning massage");
                    alert.setContentText("you must insert data");
                    alert.showAndWait();
                } else if (searchFiled.equals("Number")) {
                    if (!isInteger(bookNameText)) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Warning massage");
                        alert.setContentText("you must insert Number");
                        alert.showAndWait();
                    } else {
                        bookSearchButton(searchFiled, bookNameText.getText());
                    }
                } else {
                    bookSearchButton(searchFiled, bookNameText.getText());
                }

            }
        });


        pane.add(bookName, 0, 0);
        pane.add(bookNameText, 1, 0);
        pane.add(search, 2, 2);

        //put pane in the middle of interface
        pane.widthProperty().divide(2);
        pane.heightProperty().divide(2);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();


    }

    public void bookSearchButton(String searchFiled, String searchData) {
        Stage stage = new Stage();
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(10);
        pane.setVgap(10);


        Label bookDataLabel = new Label("The Book info  :-> ");
        // set label style by chang border width ,border color ,background color,font weight
        bookDataLabel.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");

        bookDataLabel.setAlignment(Pos.CENTER);
        pane.add(bookDataLabel, 0, 0);

        TextArea bookDataText = new TextArea();
        // set text style by chang border width ,border color ,background color,font weight
        bookDataText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookDataText.setPrefHeight(400);
        bookDataText.setPrefWidth(700);
        bookDataText.setEditable(false);
        pane.add(bookDataText, 0, 1);


        StringBuilder stringBuilder = new StringBuilder();
        if (searchFiled.equals("Number")) {
            stringBuilder.append(LibraryDriver.searchByNo(Integer.parseInt(searchData), bookArrayList));

        } else if (searchFiled.equals("Author Name")) {
            stringBuilder.append(LibraryDriver.searchByAuthor(searchData, bookArrayList));
        } else {
            stringBuilder.append(LibraryDriver.searchByTitle(searchData, bookArrayList));
        }


        bookDataText.setText(String.valueOf(stringBuilder));


        pane.widthProperty().divide(2);
        pane.heightProperty().divide(2);

        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();

    }

    public void checkBookLoansButton() {
        Stage stage = new Stage();
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
        pane.setHgap(10);
        pane.setVgap(10);


        Label bookDataLabel = new Label("Book Loans  :-> ");
        // set label style by chang border width ,border color ,background color,font weight
        bookDataLabel.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:transparent; -fx-font-weight: bold;");

        bookDataLabel.setAlignment(Pos.CENTER);
        pane.add(bookDataLabel, 0, 0);

        TextArea bookDataText = new TextArea();
        // set text style by chang border width ,border color ,background color,font weight
        bookDataText.setStyle("-fx-border-width: 0px0px2px0px; -fx-border-color: Black; -fx-background-color:white; -fx-font-weight: bold; ");
        bookDataText.setPrefHeight(400);
        bookDataText.setPrefWidth(700);
        bookDataText.setEditable(false);
        pane.add(bookDataText, 0, 1);


        StringBuilder stringBuilder = LibraryDriver.checkBookLoans(bookArrayList);

        bookDataText.setText(String.valueOf(stringBuilder));


        pane.widthProperty().divide(2);
        pane.heightProperty().divide(2);

        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }

    public static boolean isInteger(TextField textField) {
        String input = textField.getText();
        //check if text long value
        try {
            Integer.parseInt(input);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;

    }
}

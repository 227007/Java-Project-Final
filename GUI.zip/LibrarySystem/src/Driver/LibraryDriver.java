package Driver;

import Entity.Author;
import Entity.Book;
import Entity.Date;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Scanner;


public class LibraryDriver {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<Book> books = new ArrayList<>();

        int choice;

        displayMenu();
        choice = scanner.nextInt();
        while (choice != 6) {
            switch (choice) {
                case 1 -> {
                    Book book = addBook();
                    books.add(book);
                }
                case 2 -> {
                    System.out.print("Enter Book Title: ");
                    String title = scanner.nextLine();
                    System.out.println(searchByTitle(title, books));
                }
                case 3 -> {
                    System.out.print("Enter Author Name: ");
                    String name = scanner.nextLine();
                    System.out.println(searchByAuthor(name, books));

                }
                case 4 -> {
                    System.out.print("Enter Book Number: ");
                    int number = scanner.nextInt();
                    System.out.println(searchByNo(number, books));

                }
                case 5 -> System.out.println(checkBookLoans(books));

                default -> System.out.println("Invalid choice. Please enter a valid option.");

            }
            displayMenu();
            choice = scanner.nextInt();

        }
        System.out.println("Exiting the application. Goodbye!");

    }

    private static void displayMenu() {
        System.out.println("1. Add Book");
        System.out.println("2. Search For Book By Title");
        System.out.println("3. Search For Book By Author");
        System.out.println("4. Search For Book By Number");
        System.out.println("5. Check Book Loans");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private static Book addBook() {
        Book book = createBook();
        if (book == null) {
            System.out.println("Book Not been added.");

            return null;
        }
        System.out.println("Book added successfully.");

        return book;


    }

    public static Book createBook() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        Author author = createAuthor();
        System.out.print("Enter book number: ");
        int number = scanner.nextInt();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter version: ");
        String version = scanner.nextLine();
        Date date = createDate();
        if (date == null) {
            return null;
        }
        return new Book(title, author, number, genre, version, date, true);

    }

    public static Author createAuthor() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter author ID: ");
        String authorId = scanner.nextLine();
        System.out.print("Enter author Name: ");
        String authorName = scanner.nextLine();
        System.out.println("Enter author BirthDate: ");
        Date authorBirthDate = createDate();
        if (authorBirthDate == null) {
            return null;
        }
        System.out.print("Enter author Address: ");
        String authorAddress = scanner.nextLine();
        return new Author(authorId, authorName, authorAddress, authorBirthDate);
    }

    public static Date createDate() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter release date (day month year): ");
        int day = scanner.nextInt();
        int month = scanner.nextInt();
        int year = scanner.nextInt();
        if (day > 31 || month > 12) {
            System.out.println("invalid Data");
            return null;
        }
        return new Date(day, month, year);
    }


    public static String searchByTitle(String title, ArrayList<Book> books) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return "Book found: " + book.getInfo();
            }
        }
        return "Book not found.";
    }

    public static String searchByNo(int number, ArrayList<Book> books) {
        for (Book book : books) {
            if (book.getNumber() == number) {
                return "Book found: " + book.getInfo();
            }
        }
        return "Book not found.";

    }

    public static String searchByAuthor(String name, ArrayList<Book> books) {
        for (Entity.Book book : books) {
            if (book.getAuthor().getName().equalsIgnoreCase(name)) {
                return ("Book found: " + book.getInfo());
            }
        }
        return ("Book not found.");

    }

    public static StringBuilder checkBookLoans(ArrayList<Book> books) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Book Loans:").append("\n");
        for (Book book : books) {
            if (book.inLoan()) {
                stringBuilder.append(book.getTitle()).append(" by ").append(book.getAuthor()).append("\n");
                Date loanDate = book.getLoanDate();
                LocalDate loanLocalDate = LocalDate.of(loanDate.getYear(), loanDate.getMonth(), loanDate.getDay());

                long daysDifference = ChronoUnit.DAYS.between(loanLocalDate, LocalDate.now());

                if (daysDifference < 5) {
                    stringBuilder.append("Due in ").append((5 - daysDifference)).append(" days").append("\n");
                } else {
                    stringBuilder.append("Overdue by ").append((5 - daysDifference)).append(" days").append("\n");
                }

            } else {
                stringBuilder.append("No Loans Books").append("\n");
            }
        }
        return stringBuilder;
    }
}

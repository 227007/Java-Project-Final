package Entity;
import Interface.Display;

public class Author implements Display {
    private String id;
    private String name;
    private String address;
    private Date birthDate;

    public Author(String id, String name, String address, Date birthDate) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.birthDate = birthDate;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    @Override
    public String getInfo() {
        return "ID: " + id +
                ", Name: " + name +
                ", Address: " + address +
                ", Birth Date: " + birthDate.toString();
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}
package Entity;

import Interface.Display;

/**
 * @author BLT
 */
public class Book implements Display {
    private String title;
    private Author author;
    private int number;
    private String genre;
    private String version;
    private Date date;
    private boolean isInLoan;
    private Date loanDate;

    public Book(String title, Author author, int number, String genre, String version, Date date, boolean isInLoan) {
        this.title = title;
        this.author = author;
        this.number = number;
        this.genre = genre;
        this.version = version;
        this.date = date;
        this.isInLoan = isInLoan;

    }

    public Book() {
    }

    public boolean isInLoan() {
        return isInLoan;
    }

    public void setInLoan(boolean inLoan) {
        isInLoan = inLoan;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Author getAuthor() {
        return author;
    }

    public void setAuthor(Author author) {
        this.author = author;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String getInfo() {
        String loanStatus = inLoan() ? "In Loan" : "Available";
        return "Title: " + title + "\n" +
                "Author: " + author.getInfo() + "\n" +
                "No: " + number + "\n" +
                "Genre: " + genre + "\n" +
                "Version: " + version + "\n" +
                "Date: " + date.toString() + "\n" +
                "Status: " + loanStatus;
    }

    @Override
    public boolean inLoan() {
        return isInLoan;
    }

    public Date getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(Date loanDate) {
        this.loanDate = loanDate;
    }


}

package Entity;


public class Journal extends Book {
    private String conferenceName;
    private String conferenceNo;
    boolean isInLoan;

    public Journal(String conferenceName, String conferenceNo, String title, Author author, int number, String genre, String version, Entity.Date date, boolean isInLoan) {
        super(title, author, number, genre, version, date, isInLoan);
        this.conferenceName = conferenceName;
        this.conferenceNo = conferenceNo;
        this.isInLoan = isInLoan;
    }

    public void setConferenceName(String conferenceName) {
        this.conferenceName = conferenceName;
    }

    public void setConferenceNo(String conferenceNo) {
        this.conferenceNo = conferenceNo;
    }

    public String getConferenceName() {
        return conferenceName;
    }

    public String getConferenceNo() {
        return conferenceNo;
    }

    @Override
    public String getInfo() {
        return "Conference Name: " + conferenceName + ", Conference No: " + conferenceNo;
    }

    @Override
    public boolean inLoan() {
        return isInLoan;
    }
}


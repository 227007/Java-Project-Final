package Entity;


public class Magazine extends Book {
    private String issueNo;
    private Date releaseDate;
    private boolean isInLoan;

    public Magazine(String issueNo, Date releaseDate, String title, Author author, int number, String genre, String version, Date date, boolean isInLoan) {
        super(title, author, number, genre, version, date, isInLoan);
        this.issueNo = issueNo;
        this.releaseDate = releaseDate;
        this.isInLoan = isInLoan;
    }

    public void setIssueNo(String issueNo) {
        this.issueNo = issueNo;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    @Override
    public boolean isInLoan() {
        return isInLoan;
    }

    @Override
    public void setInLoan(boolean inLoan) {
        isInLoan = inLoan;
    }

    public String getIssueNo() {
        return issueNo;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    @Override
    public String getInfo() {
        return "Issue No: " + issueNo + ", Release Date: " + releaseDate.toString();
    }

    @Override
    public boolean inLoan() {
        return isInLoan;
    }
}

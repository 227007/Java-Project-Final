package Entity;


import Interface.Display;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student implements Display {
    private String id;
    private String name;
    private String address;
    private Date birthDate;
    private String major;
    private List<Book> borrowedBooks;


    public Student(String id, String name, String address, Date birthDate, String major) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.birthDate = birthDate;
        this.major = major;
        this.borrowedBooks = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public Entity.Date getBirthDate() {
        return birthDate;
    }

    public String getMajor() {
        return major;
    }

    @Override
    public String getInfo() {
        return "ID: " + id + ", Name: " + name + ", Address: "
                + address + ", Birth Date: " + birthDate.toString() + ", Major: " + major;

    }

    @Override
    public boolean inLoan() {
        return !borrowedBooks.isEmpty();
    }

    public void borrowBook(Book book) {
        if (borrowedBooks.size() < 3) {
            book.setInLoan(true);
            LocalDate currentDate = LocalDate.now();
            int day = currentDate.getDayOfMonth();
            int month = currentDate.getMonthValue();
            int year = currentDate.getYear();
            Date loanDate = new Date(day, month, year);
            book.setLoanDate(loanDate);
            borrowedBooks.add(book);
            System.out.println(name + " has borrowed the book: " + book.getTitle());
        } else {
            System.out.println(name + " cannot borrow more than 3 books at a time.");
        }
    }

    public void returnBook(Book book) {
        if (borrowedBooks.contains(book)) {
            borrowedBooks.remove(book);

            System.out.println(name + " has returned the book: " + book.getTitle());
        } else {
            System.out.println(name + " did not borrow the book: " + book.getTitle());
        }
    }

    @Override
    public String toString() {
        return
                "id : " + id + '\n' +
                        "name: " + name + '\n' +
                        "address: " + address + '\n' +
                        "birthDate: " + birthDate +
                        "major: " + major + '\n' +
                        "borrowedBooks: " + borrowedBooks;

    }
}
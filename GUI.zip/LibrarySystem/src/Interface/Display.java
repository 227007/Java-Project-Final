package Interface;


public interface Display {
     String getInfo();
    boolean inLoan();
}

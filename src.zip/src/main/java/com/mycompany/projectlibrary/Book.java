/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectlibrary;
import java.util.Date;
/**
 *
 * @author BLT
 */
public class Book implements Display{
     private String title;
    private String author;
    private int number;
    private String genre;
    private String version;
    private java.util.Date date;

    public Book(String title, String author, int number, String genre, String version, java.util.Date date) {
        this.title = title;
        this.author = author;
        this.number = number;
        this.genre = genre;
        this.version = version;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public java.util.Date getDate() {
        return date;
    }

    public void setDate(java.util.Date date) {
        this.date = date;
    }
     @Override
    public String getInfo() {
        return String.format("Title: , Author: , No: , Genre: , Version: , Date: ",
                title, author, number, genre, version, date.toString());
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}

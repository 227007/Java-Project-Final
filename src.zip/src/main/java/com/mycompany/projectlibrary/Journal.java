/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectlibrary;
import java.util.Date;
/**
 *
 * @author BLT
 */
public class Journal extends Book {
    private String conferenceName;
    private String conferenceNo;

    public Journal(String conferenceName, String conferenceNo, String title, String author, int number, String genre, String version, java.util.Date date) {
        super(title, author, number, genre, version, date);
        this.conferenceName = conferenceName;
        this.conferenceNo = conferenceNo;
    }


    public String getConferenceName() {
        return conferenceName;
    }

    public String getConferenceNo() {
        return conferenceNo;
    }

    @Override
    public String getInfo() {
        return String.format("Conference Name: %s, Conference No: %s", conferenceName, conferenceNo);
    }

    @Override
    public boolean inLoan() {
        return false;
    }
}

